from django.shortcuts import render
from django.http import HttpResponse
from django.urls import path
from project import views

# Create your views here.
def home(request):
    return HttpResponse("hello,Django")
    






